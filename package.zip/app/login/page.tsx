"use client";

import { LoginScreen } from "@/components/LoginScreen";

export default function Login() {
  return <LoginScreen />;
}
