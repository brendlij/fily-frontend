import { create } from "zustand";
import { jwtDecode } from "jwt-decode";

// Define the shape of our JWT payload
interface JwtPayload {
  sub: string; // username
  exp: number; // expiration timestamp
  isAdmin: boolean;
  // Add other claims as needed
}

// Define our auth store state
interface AuthState {
  token: string | null;
  username: string | null;
  isAdmin: boolean;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;

  // Actions
  login: (username: string, password: string) => Promise<void>;
  register: (username: string, password: string) => Promise<void>;
  logout: () => void;
  loadUserFromToken: () => boolean;
  clearError: () => void;
}

// Backend API URL
const API_URL = process.env.NEXT_PUBLIC_API_URL || "";
console.log("Auth store initialized with API URL:", API_URL);

export const useAuthStore = create<AuthState>((set, get) => ({
  token: null,
  username: null,
  isAdmin: false,
  isAuthenticated: false,
  isLoading: false,
  error: null,

  login: async (username: string, password: string) => {
    set({ isLoading: true, error: null });

    try {
      console.log("Attempting login with API URL:", API_URL);
      console.log("Full login URL:", `${API_URL}/auth/login`);

      const response = await fetch(`${API_URL}/auth/login`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ username, password }),
      });

      console.log("Login response status:", response.status);

      if (!response.ok) {
        let errorMessage = "Login failed";

        try {
          const errorData = await response.json();
          errorMessage = errorData.message || "Login failed";
          console.error("Login error details:", errorData);
        } catch (parseError) {
          console.error("Error parsing error response:", parseError);
        }

        throw new Error(errorMessage);
      }

      const data = await response.json();
      console.log("Login successful, received token");
      const { token } = data;

      // Store token in localStorage
      localStorage.setItem("auth_token", token);

      // Decode token to get user info
      const payload = jwtDecode<JwtPayload>(token);
      console.log("Token decoded, username:", payload.sub);

      set({
        token,
        username: payload.sub,
        isAdmin: payload.isAdmin,
        isAuthenticated: true,
        isLoading: false,
      });
    } catch (error) {
      console.error("Login error:", error);

      // Special handling for network errors
      const errorMessage =
        error instanceof Error
          ? error.message === "Failed to fetch"
            ? "Could not connect to server. Please check your connection and server status."
            : error.message
          : "An unknown error occurred";

      set({
        error: errorMessage,
        isLoading: false,
      });
    }
  },

  register: async (username: string, password: string) => {
    set({ isLoading: true, error: null });

    try {
      console.log("[AuthStore] Starting registration process for:", username);

      // Prüfen, ob es der erste Benutzer ist (über den neuen Endpunkt)
      // Cache umgehen mit mehreren Strategien
      const timestamp = Date.now();
      const url = `${API_URL}/public/users-exist?_=${timestamp}`;
      console.log(
        `[AuthStore] Checking users-exist with timestamp ${timestamp}: ${url}`
      );

      const checkResponse = await fetch(url, {
        cache: "no-store",
        headers: {
          "Cache-Control": "no-cache, no-store, must-revalidate",
          Pragma: "no-cache",
          Expires: "0", // RFC 1123 date format
          "X-Timestamp": timestamp.toString(),
        },
      });

      if (!checkResponse.ok) {
        console.error(
          `[AuthStore] Failed to check users-exist: ${checkResponse.status}`
        );
        throw new Error("Failed to check if users exist");
      }

      const data = await checkResponse.json();
      console.log("[AuthStore] Users exist check response:", data);
      const usersExist = data.usersExist;

      // Wenn bereits Benutzer existieren, verbiete die Registrierung
      if (usersExist) {
        console.error(
          "[AuthStore] Registration rejected - users already exist"
        );
        throw new Error("Registration is not allowed as users already exist");
      }

      console.log(
        "[AuthStore] No users exist, proceeding with registration as admin"
      );

      // Registration request mit isAdmin=true für den ersten Benutzer
      const response = await fetch(`${API_URL}/auth/register`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          username,
          password,
          isAdmin: true, // Erster Benutzer wird immer Admin
        }),
      });

      if (!response.ok) {
        let errorMessage = "Registration failed";
        try {
          const errorData = await response.json();
          errorMessage = errorData.message || errorMessage;
          console.error("[AuthStore] Registration error response:", errorData);
        } catch (e) {
          console.error("[AuthStore] Failed to parse error response:", e);
        }
        throw new Error(errorMessage);
      }

      console.log(
        "[AuthStore] Registration successful, automatically logging in"
      );

      // Nach erfolgreicher Registrierung sofort das sessionStorage-Flag setzen
      // Dies informiert andere Komponenten, dass ein Benutzer registriert wurde
      sessionStorage.setItem("userRegistered", "true");

      // After successful registration, login automatically
      await get().login(username, password);
    } catch (error) {
      console.error("[AuthStore] Registration error:", error);
      set({
        error:
          error instanceof Error ? error.message : "An unknown error occurred",
        isLoading: false,
      });
    }
  },

  logout: () => {
    console.log("[AuthStore] Logging out user");

    // Hole Username für Logging
    const username = useAuthStore.getState().username;
    console.log(`[AuthStore] Logging out user: ${username || "unknown"}`);

    // Remove token from localStorage
    localStorage.removeItem("auth_token");

    // Clean up any registration flags
    sessionStorage.removeItem("userRegistered");

    // Reset state
    set({
      token: null,
      username: null,
      isAdmin: false,
      isAuthenticated: false,
      error: null,
    });

    // Set a flag in sessionStorage to indicate we've just logged out
    // This can be used by the LoginScreen to refresh the users-exist check
    sessionStorage.setItem("justLoggedOut", "true");
    console.log("[AuthStore] Set justLoggedOut flag in sessionStorage");

    // Logging für Debugging
    setTimeout(() => {
      const flag = sessionStorage.getItem("justLoggedOut");
      console.log(
        `[AuthStore] Verified justLoggedOut flag in sessionStorage: ${flag}`
      );
    }, 50);
  },

  loadUserFromToken: () => {
    // Only run on client-side
    if (typeof window === "undefined") {
      console.log("[AuthStore] loadUserFromToken called on server, skipping");
      return false;
    }

    console.log("[AuthStore] Attempting to load user from token");
    const token = localStorage.getItem("auth_token");

    if (!token) {
      console.log("[AuthStore] No token found in localStorage");
      return false;
    }

    try {
      // Decode and verify the token
      console.log("[AuthStore] Token found, decoding");
      const payload = jwtDecode<JwtPayload>(token);

      // Check if token is expired
      const currentTime = Date.now() / 1000;
      if (payload.exp < currentTime) {
        // Token is expired, remove it and return false
        console.log("[AuthStore] Token expired, removing");
        localStorage.removeItem("auth_token");
        return false;
      }

      console.log(
        `[AuthStore] Valid token for user: ${payload.sub}, isAdmin: ${payload.isAdmin}`
      );
      console.log(
        `[AuthStore] Token expires: ${new Date(
          payload.exp * 1000
        ).toLocaleString()}`
      );

      // Token is valid, update state
      set({
        token,
        username: payload.sub,
        isAdmin: payload.isAdmin,
        isAuthenticated: true,
      });

      return true;
    } catch (error) {
      // If there's an error decoding the token, remove it
      console.error("[AuthStore] Error decoding token:", error);
      localStorage.removeItem("auth_token");
      return false;
    }
  },

  clearError: () => set({ error: null }),
}));

export default useAuthStore;
